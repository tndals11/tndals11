package test;

public class Test3 {

	public static void main(String[] args) {

	
		
		char ch = 97;
		do {
			System.out.print(ch + " ");
			ch++;
		} while (ch <= 122);
		
		
	}
}